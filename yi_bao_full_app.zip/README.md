# Yi Bao Coffee & Food — App Demo

## Có sẵn
- Trang chủ
- Menu và danh mục
- Tìm kiếm món
- Giỏ hàng lưu bằng localStorage
- Tăng/giảm số lượng
- Form đặt món
- Khuyến mãi
- Chi nhánh
- Blog
- Giao diện responsive cho điện thoại và desktop

## Đưa lên Vercel
1. Tạo tài khoản GitHub và Vercel.
2. Tạo repository mới, tải `index.html` lên.
3. Vào Vercel → Add New Project → chọn repository.
4. Deploy.
5. Có thể gắn tên miền riêng sau khi app chạy ổn.

## Lưu ý
Đây là bản frontend chạy độc lập. Phần đặt món hiện là demo. Để nhận đơn thật cần nối thêm Zalo/Google Sheets/POS/database và thay thông tin liên hệ, link bản đồ, hình ảnh món thật.
